#!/bin/bash

num="$1"
num2="$2"

echo $(( $num ** $num2))


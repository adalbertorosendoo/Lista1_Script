#!/bin/bash

echo "Digite um número inteiro"
read y
echo "Seu número inteiro somado com +1: "$(($y+1))

